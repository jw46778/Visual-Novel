# module1.rpy
# Module 1: "Reading the Data" - Meeting Dr. Sharma at the Water Authority

# Structure: Scripted intro → Chart 1 + AI → Chart 2 + AI → Chart 3 + AI → Synthesis
# Each AI segment focuses on ONE specific learning goal

# =============================================================================
# PHASE 1: ARRIVAL (Scripted Introduction)
# =============================================================================

label module1_exterior:
    scene water_authority_exterior
    with fade
    
    "The next day after school, I found myself standing outside a small county building."
    "A simple sign read: 'Millcreek County Water Authority.'"
    
    "I'd walked past this place a hundred times but never really noticed it."
    "Today felt different."
    
    "I took a deep breath and pulled open the door."
    
    jump module1_interior

label module1_interior:
    scene water_authority_interior
    with fade
    
    "The office was small. Just a few desks, filing cabinets, and a wall covered in charts and maps."
    
    show drsharma normal at center, npc_size
    with dissolve
    
    # Show the player character
    if pc_avatar == "male":
        show pcm neutral at right
    else:
        show pcf neutral at right
    
    drsharma_char "Oh. Hi there."
    
    drsharma_char "We don't usually get visitors after school hours. Can I help you with something?"
    
    pc "Are you... Dr. Sharma? The water data person?"
    
    show drsharma happy at center, npc_size
    
    drsharma_char "That's me. 'Water data person.' I like that."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "What brings a middle school student to the exciting world of groundwater monitoring?"
    
    menu:
        "I saw Ms. Elsie protesting about the water problems":
            pc "I saw Ms. Elsie and some other folks protesting in the town square yesterday."
            pc "She said the wells are failing and nobody's doing anything about it."
            
            show drsharma sad at center, npc_size
            
            drsharma_char "Elsie. Yeah, she's been... vocal about this."
            
        "My friend Jordan says the protesters are wrong":
            pc "My friend Jordan's dad works at the data center."
            pc "He says the protesters are just making stuff up. That the data center isn't the problem."
            
            show drsharma normal at center, npc_size
            
            drsharma_char "Hmm. Well, Jordan's dad has a paycheck that depends on a certain perspective."
            
        "I want to know what's actually happening with the water":
            pc "Everyone's saying different things about what's wrong with the water."
            pc "I figured if anyone has real information, it would be you."
            
            show drsharma happy at center, npc_size
            
            drsharma_char "Now that's a good instinct. Come to the source. I respect that."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "So you want data. Actual numbers."
    
    pc "Yeah. I want to understand what's really going on."
    
    show drsharma happy at center, npc_size
    
    drsharma_char "You know what? That's refreshing."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "Most people just want me to confirm what they already think."
    
    drsharma_char "Pull up a chair. I'm Dr. Maya Sharma."
    
    drsharma_char "I monitor groundwater for this county."
    
    show drsharma sad at center, npc_size
    
    drsharma_char "Commissioners don't care about numbers. But you're here to learn."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "So let's start with the basics. The aquifer itself."
    
    # Transition to Chart 1
    jump module1_chart1_intro

# =============================================================================
# CHART 1: WELL DEPTHS + AI CONVERSATION
# =============================================================================

label module1_chart1_intro:
    show drsharma normal at center, npc_size
    
    drsharma_char "Let me pull up the monitoring well data."
    
    # Show chart 1 on computer screen
    show chart_well_depths at computer_screen
    with dissolve
    
    drsharma_char "This is our main monitoring well. Tracks the water table depth over time."
    
    show drsharma sad at center, npc_size
    
    drsharma_char "Take a look at that line."
    
    # Initialize API and start focused AI conversation
    jump module1_chart1_ai

label module1_chart1_ai:
    # Initialize API key
    call get_api_key from _call_get_api_key_chart1
    
    python:
        import npc
        from npc import Controller
        
        # Controller 1: Understanding the significance of the 20-foot drop
        decline_controller = Controller(
            control_phrase="the student has mentioned ANY of these: drop, decline, fall, down, 20 feet, twenty feet, big, large, significant, a lot, unusual, not normal, weird, change, or has said ANYTHING suggesting the aquifer decreased",
            callback="module1_goal_decline_achieved"
        )
        
        # Create Dr. Sharma NPC for this focused conversation
        drsharma_npc = npc.NPC(
            character=drsharma_char,
            prompt=maya_prompt,
            controllers=[decline_controller],
            api_key=apikey
        )
    
    # Dr. Sharma's opening (focused on chart interpretation)
    $ drsharma_npc.npc_says("So. What do you see there?")
    
    # Conversation loop for Chart 1
    jump module1_chart1_conversation_loop

label module1_chart1_conversation_loop:
    $ student_input = renpy.input("What do you want to say?", length=500)
    
    if student_input.strip() == "":
        jump module1_chart1_conversation_loop
    
    pc "[student_input]"
    
    $ drsharma_npc.user_says(student_input)
    
    # Check if controller fired
    if drsharma_npc.callbacks:
        $ callback = drsharma_npc.callbacks.pop(0)
        $ renpy.jump(callback)
    
    # Continue conversation
    jump module1_chart1_conversation_loop

label module1_goal_decline_achieved:
    # Student understood the significance - hide chart and move to Chart 2
    hide chart_well_depths
    with dissolve
    
    show drsharma happy at center, npc_size
    
    drsharma_char "Exactly."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "So that's the aquifer. Now let's look at usage."
    
    jump module1_chart2_intro

# =============================================================================
# CHART 2: CONSUMPTION + AI CONVERSATION
# =============================================================================

label module1_chart2_intro:
    # Make sure previous chart is hidden
    hide chart_well_depths
    
    show drsharma normal at center, npc_size
    
    drsharma_char "See that chart on the wall?"
    
    # Show chart 2 as wall poster
    show chart_consumption at wall_poster
    with dissolve
    
    drsharma_char "Water consumption. Two bars."
    
    show drsharma sad at center, npc_size
    
    drsharma_char "Tell me what you see."
    
    # Start focused AI conversation
    jump module1_chart2_ai

label module1_chart2_ai:
    python:
        import npc
        from npc import Controller
        
        # Controller 2: Understanding the 3x disparity
        disparity_controller = Controller(
            control_phrase="the student has mentioned ANY of these: data center uses more, way more, a lot more, much more, 3 times, three times, more water, big difference, uses most, or has said ANYTHING comparing data center usage to town usage",
            callback="module1_goal_disparity_achieved"
        )
        
        # Create new NPC instance for this conversation
        drsharma_npc = npc.NPC(
            character=drsharma_char,
            prompt=maya_prompt,
            controllers=[disparity_controller],
            api_key=apikey
        )
    
    # Dr. Sharma's opening
    $ drsharma_npc.npc_says("What does that comparison tell you?")
    
    # Conversation loop for Chart 2
    jump module1_chart2_conversation_loop

label module1_chart2_conversation_loop:
    $ student_input = renpy.input("What do you want to say?", length=500)
    
    if student_input.strip() == "":
        jump module1_chart2_conversation_loop
    
    pc "[student_input]"
    
    $ drsharma_npc.user_says(student_input)
    
    # Check if controller fired
    if drsharma_npc.callbacks:
        $ callback = drsharma_npc.callbacks.pop(0)
        $ renpy.jump(callback)
    
    # Continue conversation
    jump module1_chart2_conversation_loop

label module1_goal_disparity_achieved:
    # Student understood the disparity - move to Chart 3
    show drsharma happy at center, npc_size
    
    drsharma_char "Right."
    
    hide chart_consumption
    with dissolve
    
    show drsharma normal at center, npc_size
    
    drsharma_char "Now. The timeline."
    
    jump module1_chart3_intro

# =============================================================================
# CHART 3: TIMELINE + AI CONVERSATION
# =============================================================================

label module1_chart3_intro:
    # Make sure previous chart is hidden
    hide chart_consumption
    
    show drsharma normal at center, npc_size
    
    drsharma_char "That poster shows when things happened."
    
    # Show chart 3 as wall poster
    show chart_timeline at wall_poster
    with dissolve
    
    drsharma_char "Take a look."
    
    show drsharma sad at center, npc_size
    
    drsharma_char "What's the pattern?"
    
    # Start focused AI conversation
    jump module1_chart3_ai

label module1_chart3_ai:
    python:
        import npc
        from npc import Controller
        
        # Controller 3: Understanding the timing correlation
        timing_controller = Controller(
            control_phrase="the student has said ANYTHING about timing, 2022, June, when something started, correlation, or connection between events",
            callback="module1_goal_timing_achieved"
        )
        
        # Create new NPC instance for this conversation
        drsharma_npc = npc.NPC(
            character=drsharma_char,
            prompt=maya_prompt,
            controllers=[timing_controller],
            api_key=apikey
        )
    
    # Dr. Sharma's opening
    $ drsharma_npc.npc_says("When did the data center open? When did the problems start?")
    
    # Conversation loop for Chart 3
    jump module1_chart3_conversation_loop

label module1_chart3_conversation_loop:
    $ student_input = renpy.input("What do you want to say?", length=500)
    
    if student_input.strip() == "":
        jump module1_chart3_conversation_loop
    
    pc "[student_input]"
    
    $ drsharma_npc.user_says(student_input)
    
    # Check if controller fired
    if drsharma_npc.callbacks:
        $ callback = drsharma_npc.callbacks.pop(0)
        $ renpy.jump(callback)
    
    # Continue conversation
    jump module1_chart3_conversation_loop

label module1_goal_timing_achieved:
    # Student understood the timing - move to synthesis
    show drsharma happy at center, npc_size
    
    drsharma_char "There it is."
    
    hide chart_timeline
    with dissolve
    
    show drsharma normal at center, npc_size
    
    jump module1_synthesis

# =============================================================================
# SYNTHESIS & CONCLUSION (Scripted)
# =============================================================================

label module1_synthesis:
    # Make sure all charts are hidden
    hide chart_well_depths
    hide chart_consumption
    hide chart_timeline
    
    show drsharma normal at center, npc_size
    
    drsharma_char "You just put together what took the county six months to admit."
    
    drsharma_char "Twenty-foot drop. Three-times the usage. June 2022."
    
    show drsharma sad at center, npc_size
    
    drsharma_char "You'd think data this clear would lead to action."
    
    drsharma_char "But tax revenue beats science every time around here."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "Officially, we're 'monitoring the situation.'"
    
    pc "That's frustrating."
    
    show drsharma sad at center, npc_size
    
    drsharma_char "Welcome to the real world, kid."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "But now you understand. You've got the numbers."
    
    show drsharma happy at center, npc_size
    
    drsharma_char "If you want to dig deeper, talk to other people in town."
    
    show drsharma normal at center, npc_size
    
    drsharma_char "See how this affects them. Get more perspectives."
    
    show drsharma happy at center, npc_size
    
    drsharma_char "Good work today."
    
    # Fade out
    scene bg black
    with fade
    
    "I left the Water Authority office with the data clear in my mind."
    
    "Twenty feet. Three times the usage. June 2022."
    
    "The numbers told a story."
    
    "Ms. Elsie was right. Dr. Sharma knew it. The commissioners knew it."
    
    "But knowing and doing something about it? Those were two different things."
    
    # This will eventually continue to Module 2
    return
