# avatar_selection.rpy
# Screen for choosing player avatar



default pc_avatar = "male"  # Default value, will be changed by selection

screen avatar_select:
    modal True
    
    # Background
    add "#000000"
    
    # Title text at top
    text "Which one looks most like how you think you look?":
        xalign 0.5
        ypos 100
        size 36
        text_align 0.5
    
    # Male avatar on left
    vbox:
        xalign 0.35
        yalign 0.5
        spacing 20
        
        imagebutton:
            idle "pcm neutral.png"
            hover "pcm neutral glow.png"
            action [SetVariable("pc_avatar", "male"), Return()]
            xalign 0.5
        
        text "Option A":
            xalign 0.5
            size 24
            color "#aaa"
    
    # Female avatar on right
    vbox:
        xalign 0.65
        yalign 0.5
        spacing 20
        
        imagebutton:
            idle "pcf neutral.png"
            hover "pcf neutral glow.png"
            action [SetVariable("pc_avatar", "female"), Return()]
            xalign 0.5
        
        text "Option B":
            xalign 0.5
            size 24
            color "#aaa"