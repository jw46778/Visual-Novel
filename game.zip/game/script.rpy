﻿# This is the script for Millcreek Water Trouble, the game we're making. 

# This is from Danse Macabre and initializes the ChatGPT connection. 
init python:
    import npc
    import chatgpt
    import re

# This is the API key. We'll need to move this to a proxy; leaving it in the code isn't safe. Rob has a plan for how to do this. 
label get_api_key:
    $ apikey = "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"
    return

# Declaring the characters in the game. The color argument colorizes the
# name of the character.
default player_name = "Student"
define e = Character("Elsie", color="#4a9933")
define pc = Character("[player_name]", color="#0F0FAF")
define jordan = Character("Jordan", color="#aCAF50")

# The game starts here.

label start:
    # Let's figure out who is playing the game
    $ player_name = renpy.input("What is your name?", length=20)
    $ if player_name.strip() == "": player_name = "Student"
    
    # Then student ID
    $ student_id = renpy.input("Enter your student ID:", length=20)
    $ if student_id.strip() == "": student_id = "no_id_entered"

     # Show avatar selection screen
    call screen avatar_select

    call pre_test_start from _call_pre_test_start

    jump intro_scene1


    
    return 

return
