# introscene.rpy - Corrected version using actual Danse Macabre NPC API

# Transforms for character sizing and movement
transform npc_size:
    zoom 1.3

transform enter_from_left:
    xalign -0.3
    yalign 1.0
    linear 0.8 xalign 0.2

transform crowd_background:
    fit "cover"
    align (0.5, 1.0)

# Scene 1: Walking through town
label intro_scene1:
    scene townhall day
    "I've lived in Millcreek my whole life. It's a country town somewhere between Atlanta and Savannah."
    "The people who live here are usually very proud of our town."
    "Each day, after I get out of school, I like to walk home through the town square."
    "Normally, it's very peaceful, with just people going out doing their business."
    "But today, something was different..."
    jump intro_scene2

# Scene 2: Meeting Elsie at the protest (NPC INTERACTION)
label intro_scene2:
    scene townhall day
    
    # Show the protestor crowd
    show protestor crowd at crowd_background
    
    "Some of my neighbors and people I knew from town were in the square holding signs!"
    "No one in Millcreek ever protests. That's for people who live in the city!"
    "I couldn't believe it."
    
    # Elsie enters from the left
    show elsie protesting at enter_from_left, npc_size
    
    # Show the player character
    if pc_avatar == "male":
        show pcm neutral at center
    else:
        show pcf neutral at center
    
    pc "Ms. Elsie! What are you doing here today?"
    
    # Initialize the API key
    call get_api_key from _call_get_api_key
    
    # Create Elsie as an NPC
    python:
        import npc
        from npc import Controller
        
        # Create the goodbye controller
        # When the student says goodbye, jump to intro_scene3
        goodbye_controller = Controller(
            control_phrase="the user has said goodbye, wants to leave, or is ending the conversation (examples: bye, see you later, I gotta go, I should get going, talk to you later, thanks)",
            callback="intro_scene3"  # This is a LABEL NAME, not a function
        )
        
        # Create Elsie NPC
        # elsie_char and elsie_prompt are defined in elsie_npc.rpy
        elsie_npc = npc.NPC(
            character=elsie_char,  # Character object
            prompt=elsie_prompt,   # Full prompt string
            controllers=[goodbye_controller],
            api_key=apikey
        )
    
    # Elsie's initial greeting
    $ elsie_npc.npc_says("Oh, hello sweetie! Well, I'm here because somebody's got to stand up for this town. Our water situation is getting serious.")
    
    # Conversation loop
    label elsie_conversation_loop:
        # Get student input
        $ student_input = renpy.input("What do you want to say to Elsie?", length=500)
        
        # If empty, loop back
        if student_input.strip() == "":
            jump elsie_conversation_loop
        
        # Show what the student said
        pc "[student_input]"
        
        # Elsie responds (and runs controllers)
        $ elsie_npc.user_says(student_input)
        
        # Check if any controllers triggered
        if elsie_npc.callbacks:
            # Pop the first callback label name
            $ callback_label = elsie_npc.callbacks.pop(0)
            # Jump to that label
            $ renpy.jump(callback_label)
        
        # No callback triggered, continue conversation
        jump elsie_conversation_loop

# Scene 3: At home
label intro_scene3:
    # Clear the protest scene
    scene bg black
    with fade
    
    "I couldn't stop thinking about what Ms. Elsie said even when I got to my house."
       
    # Transition to home
    scene home exterior
    with dissolve
    
    "I decided to go right to my room and think about it. "
    # A simple "video call" frame with Jordan's face
    scene videocall background  # Tablet screen on a bed. 
    "When I got to my room, my tablet buzzed. A video call from my friend Jordan!"
    show jordan videocall:
        xalign 0.475   # Horizontal center (adjust if tablet is off-center)
        yalign 0.55   # Vertical position (adjust to match tablet screen)
        zoom 0.80   # Scale down to fit tablet screen (adjust as needed)
    with dissolve
    
    jordan "Hey! I saw you at the protest today. What was that all about?"
    
    # Player's first response - multiple options, but all lead to Jordan explaining
    menu:
        "What do you mean? You didn't know about it?":
            pc "What do you mean? You didn't know about the protest?"
            jordan "I mean, yeah, I heard people were upset about water or whatever."
            jordan "But my dad says it's all overblown."
        
        "Ms. Elsie and others are worried about the water.":
            pc "Ms. Elsie and a bunch of neighbors are really worried about the water situation."
            jordan "Yeah, I heard. My dad's been talking about it."
            jordan "He thinks people are making a big deal out of nothing."
        
        "Have you noticed anything weird with your water?":
            pc "Haven't you noticed anything weird? Like, has your water pressure dropped?"
            jordan "Nah, our water's fine. My dad says that's because we're on the town system, not a well."
            jordan "He thinks all this protest stuff is overblown."
    
    # Jordan continues - his dad's perspective
    jordan "My dad works at the data center, you know."
    jordan "He says the protesters don't understand how things work."
    
    # Second menu - player pushes back or asks questions
    menu:
        "But what about all the wells that are failing?":
            pc "But Jordan, what about all the wells that are failing? Ms. Elsie's well barely works anymore."
            jordan "Dad says that's just normal variation. Wells fail sometimes."
            jordan "It doesn't mean the data center caused it."
        
        "What does your dad say about the water usage?":
            pc "What does your dad say about how much water the data center uses?"
            jordan "He says it's all permitted. The county approved everything."
            jordan "They wouldn't have let them build it if it was dangerous."
        
        "Does he have data to back that up?":
            pc "Does he have actual data to back that up? Or is he just guessing?"
            jordan "I mean... he works there. He knows what he's talking about."
            jordan "The county says it's fine. That's all that matters, right?"
    
    # Jordan's conclusion - his dad's position
    jordan "Look, my dad says they're just misreading the data."
    jordan "Or maybe they're not even looking at real data. Just going by feelings."
    jordan "The data center is good for Millcreek. Jobs, taxes, all that."
    
    # Third menu - player's response before ending the call
    menu:
        "Maybe. But I want to see the data myself.":
            pc "Maybe he's right. But I want to actually look at the data myself."
            jordan "Sure, whatever. Let me know what you find."
        
        "I don't know. Something feels off about this.":
            pc "I don't know, Jordan. Something just feels off about the whole situation."
            jordan "You sound like the protesters now."
            jordan "But hey, if you want to dig into it, go for it."
        
        "Someone needs to actually check the numbers.":
            pc "Someone needs to actually check the numbers. Not just trust what people say."
            jordan "Okay, detective. Good luck with that."
    
    # End the call
    jordan "Anyway, I gotta go. Talk later?"
    
    pc "Yeah, later."
    
    # Transition out of video call
    hide jordan videocall
    with dissolve
    
    
    "Jordan's dad says the protesters are wrong."
    "Ms. Elsie says the county won't listen."
    "Everyone has opinions. But nobody seems to have actual answers."
    
    "I searched on my tablet for 'Millcreek water data.'"
    
    "Most of what came up was about the data center."
    show water web:
        xalign 0.475   # Horizontal center (adjust if tablet is off-center)
        yalign 0.55   # Vertical position (adjust to match tablet screen)
        zoom 0.80   # Scale down to fit tablet screen (adjust as needed)
    with dissolve
    "And then I found something: the County Water Authority has an office."
    
    "They're supposed to monitor wells and water usage."
    
    "If anyone has real data, they do."
    
    # Decision point
    "Tomorrow after school, I'm going to find out what's actually happening."
    
    # Fade to black before module 1
    scene bg black
    with fade
    
    "The next day..."
    
    # Jump to Module 1 - meeting Dr. Sharma
    jump module1_exterior


    return
