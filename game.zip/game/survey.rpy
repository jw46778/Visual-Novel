# survey.rpy
# Pre-test and Post-test STEM Identity Survey
# Writes results to a CSV file in the game directory
#
# NOTES FOR THE TEAM:
# - Questions here are PLACEHOLDERS. Work with COE colleagues on the 
#   validated instrument you want to use (e.g., STEM Identity Scale).
# - The mechanism works regardless of which questions you drop in.
# - For the prototype demo, these questions are fine.
# - student_id is set during initial setup (see script.rpy)

# ---------------------------------------------------------------------------
# PYTHON INITIALIZATION
# ---------------------------------------------------------------------------

init python:
    import csv
    import os
    import datetime

    # ---------------------------------------------------------------------------
    # Survey questions - each tuple is (variable_name, question_text)
    # Change these to match your validated instrument.
    # ---------------------------------------------------------------------------
    
    pre_test_questions = [
        ("stem_enjoy",      "I enjoy doing activities related to science, technology, engineering, or math."),
        ("stem_identity",   "I think of myself as a science person."),
        ("stem_ability",    "I believe I can do well in science and math."),
        ("stem_belong",     "I feel like I belong in science and math activities."),
        ("stem_future",     "I can imagine myself doing something related to science or technology in the future."),
        ("stem_useful",     "I think science and math are useful in everyday life."),
        ("stem_interest",   "I am interested in how technology affects the world around me."),
        ("stem_confident",  "I feel confident when I have to solve a problem using data or evidence."),
    ]

    post_test_questions = pre_test_questions

    # ---------------------------------------------------------------------------
    # Storage for responses during the session
    # ---------------------------------------------------------------------------
    
    pre_test_responses = {}
    post_test_responses = {}

    # ---------------------------------------------------------------------------
    # CSV writing function
    # ---------------------------------------------------------------------------
    
    def save_survey(filename, responses, questions):
        filepath = os.path.join(renpy.config.gamedir, filename)
        
        file_is_new = not os.path.exists(filepath) or os.path.getsize(filepath) == 0

        with open(filepath, 'a', newline='') as f:
            writer = csv.writer(f)

            if file_is_new:
                header = ['timestamp', 'student_id'] + [q[0] for q in questions]
                writer.writerow(header)

            row = [
                str(datetime.datetime.now()),
                student_id
            ]
            for q_id, q_text in questions:
                row.append(responses.get(q_id, 'MISSING'))
            
            writer.writerow(row)


# ---------------------------------------------------------------------------
# LIKERT SCREEN
# ---------------------------------------------------------------------------
# Gemini's screen, used as-is. It expects:
#   the_question - the text to display
#   variable_name - a STRING name of a store variable to set (e.g. "stem_enjoy")
#
# The calling pattern for each question is three lines:
#   1. Initialize the store variable to 0 (so getattr doesn't crash)
#   2. call screen (blocks until the student clicks Submit)
#   3. Copy the store variable into the response dictionary
#
# Example:
#   $ stem_enjoy = 0
#   call screen likert_question("Question text here", "stem_enjoy")
#   $ pre_test_responses["stem_enjoy"] = stem_enjoy
# ---------------------------------------------------------------------------

screen likert_question(the_question, variable_name):
    modal True

    frame:
        xalign 0.5
        yalign 0.4
        xsize 1000
        padding (40, 40)
        
        vbox:
            spacing 30
            xsize 920
            
            text the_question:
                xalign 0.5
                size 30
                text_align 0.5
            null height 20
            hbox:
                xalign 0.5
                spacing 40
                
                for i in range(1, 6):
                    vbox:
                        spacing 10
                        xsize 80
                        xalign 0.5
                        
                        textbutton str(i):
                            action SetVariable(variable_name, i)
                            background ("#444" if getattr(store, variable_name) != i else "#0099cc") 
                            xsize 60
                            ysize 60
                            xalign 0.5
                            text_xalign 0.5
                            text_yalign 0.5
                        
                        if i == 1:
                            text "Strongly\nDisagree" size 14 xalign 0.5 text_align 0.5 color "#aaa"
                        elif i == 5:
                            text "Strongly\nAgree" size 14 xalign 0.5 text_align 0.5 color "#aaa"
                        else:
                            text "\n" size 14 xalign 0.5 
            null height 30
            if getattr(store, variable_name) != 0:
                textbutton "Submit Response":
                    xalign 0.5
                    action Return()
                    padding (20, 10)
                    background "#333"


# ---------------------------------------------------------------------------
# PRE-TEST
# ---------------------------------------------------------------------------

label pre_test_start:
    scene lab_back    
    "Before we begin, we'd like to know a little bit about how you feel about science and technology."
    "For each statement, click the number that best matches how you feel."
    "There are no right or wrong answers."
    "1 means you strongly disagree with the statement. 5 means you strongly agree."
    
    jump pre_test_q1

label pre_test_q1:
    scene lab_back
    $ stem_enjoy = 0
    call screen likert_question("Question 1 of 8\n\nI enjoy doing activities related to science, technology, engineering, or math.", "stem_enjoy")
    $ pre_test_responses["stem_enjoy"] = stem_enjoy
    jump pre_test_q2

label pre_test_q2:
    scene lab_back
    $ stem_identity = 0
    call screen likert_question("Question 2 of 8\n\nI think of myself as a science person.", "stem_identity")
    $ pre_test_responses["stem_identity"] = stem_identity
    jump pre_test_q3

label pre_test_q3:
    scene lab_back
    $ stem_ability = 0
    call screen likert_question("Question 3 of 8\n\nI believe I can do well in science and math.", "stem_ability")
    $ pre_test_responses["stem_ability"] = stem_ability
    jump pre_test_q4

label pre_test_q4:
    scene lab_back
    $ stem_belong = 0
    call screen likert_question("Question 4 of 8\n\nI feel like I belong in science and math activities.", "stem_belong")
    $ pre_test_responses["stem_belong"] = stem_belong
    jump pre_test_q5

label pre_test_q5:
    scene lab_back
    $ stem_future = 0
    call screen likert_question("Question 5 of 8\n\nI can imagine myself doing something related to science or technology in the future.", "stem_future")
    $ pre_test_responses["stem_future"] = stem_future
    jump pre_test_q6

label pre_test_q6:
    scene lab_back
    $ stem_useful = 0
    call screen likert_question("Question 6 of 8\n\nI think science and math are useful in everyday life.", "stem_useful")
    $ pre_test_responses["stem_useful"] = stem_useful
    jump pre_test_q7

label pre_test_q7:
    scene lab_back
    $ stem_interest = 0
    call screen likert_question("Question 7 of 8\n\nI am interested in how technology affects the world around me.", "stem_interest")
    $ pre_test_responses["stem_interest"] = stem_interest
    jump pre_test_q8

label pre_test_q8:
    scene lab_back
    $ stem_confident = 0
    call screen likert_question("Question 8 of 8\n\nI feel confident when I have to solve a problem using data or evidence.", "stem_confident")
    $ pre_test_responses["stem_confident"] = stem_confident
    jump pre_test_complete

label pre_test_complete:
    scene lab_back
    
    python:
        save_survey("pre_test_results.csv", pre_test_responses, pre_test_questions)
    
    "Thank you! Your answers have been saved."
    "Now let's get started."
    
    return


# ===========================================================================
# POST-TEST
# ===========================================================================

label post_test_start:
    scene lab_back
    
    "Great work on the investigation! Before we finish, we have a few more questions."
    "These are the same questions from the beginning. Answer based on how you feel right now."
    "Again, there are no right or wrong answers."
    
    jump post_test_q1

label post_test_q1:
    scene lab_back
    $ stem_enjoy = 0
    call screen likert_question("Question 1 of 8\n\nI enjoy doing activities related to science, technology, engineering, or math.", "stem_enjoy")
    $ post_test_responses["stem_enjoy"] = stem_enjoy
    jump post_test_q2

label post_test_q2:
    scene lab_back
    $ stem_identity = 0
    call screen likert_question("Question 2 of 8\n\nI think of myself as a science person.", "stem_identity")
    $ post_test_responses["stem_identity"] = stem_identity
    jump post_test_q3

label post_test_q3:
    scene lab_back
    $ stem_ability = 0
    call screen likert_question("Question 3 of 8\n\nI believe I can do well in science and math.", "stem_ability")
    $ post_test_responses["stem_ability"] = stem_ability
    jump post_test_q4

label post_test_q4:
    scene lab_back
    $ stem_belong = 0
    call screen likert_question("Question 4 of 8\n\nI feel like I belong in science and math activities.", "stem_belong")
    $ post_test_responses["stem_belong"] = stem_belong
    jump post_test_q5

label post_test_q5:
    scene lab_back
    $ stem_future = 0
    call screen likert_question("Question 5 of 8\n\nI can imagine myself doing something related to science or technology in the future.", "stem_future")
    $ post_test_responses["stem_future"] = stem_future
    jump post_test_q6

label post_test_q6:
    scene lab_back
    $ stem_useful = 0
    call screen likert_question("Question 6 of 8\n\nI think science and math are useful in everyday life.", "stem_useful")
    $ post_test_responses["stem_useful"] = stem_useful
    jump post_test_q7

label post_test_q7:
    scene lab_back
    $ stem_interest = 0
    call screen likert_question("Question 7 of 8\n\nI am interested in how technology affects the world around me.", "stem_interest")
    $ post_test_responses["stem_interest"] = stem_interest
    jump post_test_q8

label post_test_q8:
    scene lab_back
    $ stem_confident = 0
    call screen likert_question("Question 8 of 8\n\nI feel confident when I have to solve a problem using data or evidence.", "stem_confident")
    $ post_test_responses["stem_confident"] = stem_confident
    jump post_test_complete

label post_test_complete:
    scene lab_back
    
    python:
        save_survey("post_test_results.csv", post_test_responses, post_test_questions)
    
    "Thank you! Your answers have been saved."
    "You did a great job investigating the water situation in Millcreek."
    
    return
