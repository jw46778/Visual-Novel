transform larger:
    zoom 1.5

transform smaller:
    zoom 0.7

transform npc_size:
    zoom 1.3

transform enter_from_left:
    xalign -0.3  # Start off-screen to the left
    yalign 1.0
    linear 0.8 xalign 0.2  # Slide to left position over 0.8 seconds

transform fullwidth:
    xsize 1920  # Or whatever your game resolution width is
    yalign 1.0  # Anchor to bottom


transform fit_background:
    fit "cover"  # Fills the screen, crops if needed
    align (0.5, 1.0)  # Center horizontally, bottom vertically

# Chart display transforms
transform computer_screen:
    zoom 0.4  # Smaller, like it's on a monitor
    xalign 0.3  # Left side where desk/computer would be
    yalign 0.4  # Upper area

transform wall_poster:
    zoom 0.5  # Poster-sized
    xalign 0.7  # Right side of screen (wall area)
    yalign 0.3  # Upper area like it's hung on wall