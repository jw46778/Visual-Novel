__version__ = "0.0.2"

# Import necessary modules
import chatgpt
import re
import json
import traceback
import textwrap
import renpy.exports as renpy


# -----------------------------
# NPC Engine (fixed / tightened)
# -----------------------------
#
# Key changes vs. prior version:
# - Adds a persistent "guardrail" system message to keep NPCs in-scene and on-task.
#   This guardrail is stored at messages[1] (messages[0] remains the persona/system prompt).
# - Prevents the guardrail from being popped during history trimming.
# - Sanitizes user input BEFORE adding it to message history (so the model sees the cleaned version).
# - Updates Controller to ignore BOTH system messages (persona + guardrail) when evaluating triggers.


class NPC:
    """
    A Non-Player Character (NPC) wrapper around a ChatGPT-style chat completion API.

    conversation layout:
        messages[0] => system persona prompt (per-NPC)
        messages[1] => system guardrail prompt (global / per-NPC)
        messages[2:] => alternating user/assistant turns
    """

    DEFAULT_GUARDRAIL = (
        "STAY-IN-SCENE AND ON-TASK RULES (IMPORTANT):\n"
        "- Stay in-character and stay in the current scene and activity.\n"
        "- If the user asks something unrelated to the current scene/task (general trivia, distances to places, "
        "unrelated homework, pop culture, etc.), do NOT answer it.\n"
        "- Instead, politely say you can't help with that here (or you don't know), and redirect back to the current "
        "scene/task with a helpful question.\n"
        "- Never invent missing facts. If the scene/task does not provide a detail, say it is not provided or you do not know.\n"
        "- Keep responses age-appropriate and supportive.\n"
    )

    def __init__(self, character, prompt, controllers=None, proxy='', api_key='', guardrail=None):
        self.prompt = prompt
        self.controllers = controllers if controllers is not None else []
        self.character = character

        self.proxy = proxy
        self.api_key = api_key

        # Keep module refs on the instance so __getstate__/__setstate__ remain consistent.
        self.chatgpt = chatgpt
        self.re = re
        self.json = json

        # System messages: persona prompt + guardrail
        self.guardrail = guardrail if guardrail is not None else self.DEFAULT_GUARDRAIL
        self.messages = [
            {"role": "system", "content": self.prompt},
            {"role": "system", "content": self.guardrail},
        ]

        # A list of labels that the NPC requests the main thread to callback.
        # For some reasons it doesn't work if the NPC calls them directly.
        self.callbacks = []

    # To be able to save we need to make this object picklable
    def __getstate__(self):
        state = self.__dict__.copy()
        # Remove unpicklable module refs
        state['chatgpt'] = None
        state['re'] = None
        state['json'] = None
        return state

    def __setstate__(self, state):
        # Restore the instance state from the state dictionary
        self.__dict__.update(state)
        import chatgpt as _chatgpt
        import re as _re
        import json as _json
        self.chatgpt = _chatgpt
        self.re = _re
        self.json = _json

        # Backward compatibility: if an older save lacks guardrail/messages[1], repair it.
        if not hasattr(self, "guardrail") or self.guardrail is None:
            self.guardrail = self.DEFAULT_GUARDRAIL

        if not hasattr(self, "messages") or not isinstance(self.messages, list) or len(self.messages) == 0:
            self.messages = [{"role": "system", "content": getattr(self, "prompt", "")}]

        # Ensure messages[0] persona prompt exists
        if self.messages[0].get("role") != "system":
            self.messages.insert(0, {"role": "system", "content": getattr(self, "prompt", "")})

        # Ensure messages[1] guardrail exists
        if len(self.messages) < 2 or self.messages[1].get("role") != "system":
            self.messages.insert(1, {"role": "system", "content": self.guardrail})
        else:
            # Keep it fresh, in case guardrail changed between versions
            self.messages[1]["content"] = self.guardrail

    def _ensure_guardrail(self):
        """Ensure the guardrail remains as messages[1] without growing the list."""
        if len(self.messages) < 2:
            # If list got corrupted, rebuild minimal structure.
            persona = self.messages[0] if len(self.messages) == 1 else {"role": "system", "content": self.prompt}
            self.messages = [persona, {"role": "system", "content": self.guardrail}]
            return

        if self.messages[0].get("role") != "system":
            self.messages.insert(0, {"role": "system", "content": self.prompt})

        if self.messages[1].get("role") != "system":
            self.messages.insert(1, {"role": "system", "content": self.guardrail})
        else:
            self.messages[1]["content"] = self.guardrail

    # Makes the NPC say something (manually injected assistant line)
    def npc_says(self, message, display_message=True):
        self._ensure_guardrail()
        self.messages.append({"role": "assistant", "content": message})
        if display_message:
            self.display_line_by_line(message)

    # Process user input and add it to the message history
    def user_says(self, user_input):
        self._ensure_guardrail()

        # Remove any weird characters BEFORE adding to messages so the model sees the cleaned text
        cleaned_input = self.re.sub(r"[^\w\s\'!\(\)\?\.\,\:\;\-]", "", user_input)

        # Append the cleaned user input to the message history
        self.messages.append({"role": "user", "content": cleaned_input})

        # Ensure the message history does not exceed the 10000-character limit.
        # Keep messages[0] (persona) and messages[1] (guardrail) intact.
        while len(str(self.messages)) > 10000:
            # First removable turn is at index 2 (oldest non-system message)
            if len(self.messages) > 2:
                self.messages.pop(2)
            else:
                break

        # Attempt to generate a response using the ChatGPT API
        try:
            self.messages = self.chatgpt.completion(self.messages, proxy=self.proxy, api_key=self.api_key)
            response = self.messages[-1]["content"]
        except Exception:
            # Display an error message if the API call fails
            raw_trace = traceback.format_exc()
            raw_trace = self.re.sub(r"[{}\[\]]", "", raw_trace)
            safe_trace = renpy.filter_text_tags(raw_trace, allow=[])
            response = "(There was an error, please try again.)\n" + safe_trace

        # Display the NPC's response line by line with a specified wrap
        split = textwrap.wrap(response, width=200)
        for line in split:
            line = line.strip()
            if line:
                self.character(line)

        # Finally call the controllers
        for controller in self.controllers:
            result = controller.control(self.messages, self.proxy, api_key=self.api_key)
            if result is not None:
                self.callbacks.append(result)

    # Split a given text into sentences and display them one by one
    def display_line_by_line(self, text):
        # If the text is short enough, we display it in one time.
        if len(text) < 150:
            self.character(text)
            return

        # Split the text into sentences using regular expressions
        split_into_sentences = self.re.split(r'\.\s|\n\n', text)

        # Iterate through the sentences and display them
        for sentence in split_into_sentences:
            sentence = sentence.strip()
            if sentence:
                self.character(sentence)


class Controller:
    """
    Analyzes a conversation and checks if specific keywords/conditions have been mentioned,
    triggering a callback function if the conditions are met.
    """

    def __init__(self, control_phrase, callback, activated=True, permanent=False):
        self.prompt = (
            "I want you to act as a sentence analyser that responds to questions based on a conversation "
            "between a user and an assistant.\n"
            "if (" + control_phrase + ") then respond this exact word '<TRUE>'\n"
            "else respond this exact word '<FALSE>'"
        )

        self.callback = callback
        self.activated = activated
        self.permanent = permanent

    def control(self, messages, proxy, api_key):
        if not self.activated:
            return None

        # Work on a copy, and remove system messages (persona + guardrail) if present
        few_last_messages = messages.copy()

        # Remove all leading system messages
        while few_last_messages and few_last_messages[0].get("role") == "system":
            few_last_messages.pop(0)

        # Ensure the message history does not exceed the 5000-character limit
        while len(str(few_last_messages)) > 5000 and few_last_messages:
            few_last_messages.pop(0)

        control_messages = [
            {"role": "system", "content": self.prompt},
            {
                "role": "user",
                "content": (
                    "Here is the conversation between the user and the assistant \n\n <"
                    + json.dumps(few_last_messages)
                    + "> \n\n"
                    + self.prompt
                ),
            },
        ]

        try:
            response = chatgpt.completion(control_messages, proxy=proxy, api_key=api_key)[-1]["content"]
        except Exception:
            response = "<FALSE> ERROR"

        if "<TRUE>" in response and "<FALSE>" not in response and self.callback is not None:
            if not self.permanent:
                self.activated = False
            return self.callback

        return None
